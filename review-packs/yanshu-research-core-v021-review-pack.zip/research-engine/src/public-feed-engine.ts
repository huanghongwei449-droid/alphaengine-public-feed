// Compatibility entrypoint retained for existing imports. The live v0.21
// research core is implemented in company-research-engine.ts.
export { CompanyResearchEngine as PublicFeedResearchEngine } from "./company-research-engine.js";
