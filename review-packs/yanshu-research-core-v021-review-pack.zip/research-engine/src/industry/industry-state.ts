import type { IndustrySnapshot } from "@yanshu/data-providers";

export const industryState = (snapshot: IndustrySnapshot | null): "增强" | "偏强" | "中性" | "转弱" | "退潮" | "数据不足" => {
  if (!snapshot || snapshot.status !== "ok") return "数据不足";
  const changes = snapshot.boards?.map((board) => board.changePct).filter((value): value is number => value !== undefined) ?? [];
  if (!changes.length) return "数据不足";
  const average = changes.reduce((sum, value) => sum + value, 0) / changes.length;
  if (average >= 3) return "增强";
  if (average >= 1) return "偏强";
  if (average <= -3) return "退潮";
  if (average <= -1) return "转弱";
  return "中性";
};

export const industryConclusion = (snapshot: IndustrySnapshot | null): string => {
  if (!snapshot) return "所属行业和主题尚未取得可靠公开资料。";
  if (snapshot.status !== "ok") return `已确认所属行业为${snapshot.primaryIndustry}${snapshot.themes.length ? `，相关主题包括${snapshot.themes.slice(0, 8).join("、")}` : ""}；当前缺少可核验的行业表现数据，暂不把个股涨跌当作产业强弱。`;
  return `已确认所属行业为${snapshot.primaryIndustry}${snapshot.themes.length ? `，相关主题包括${snapshot.themes.join("、")}` : ""}。`;
};
