import type { CompanyResearchBrief } from "@yanshu/research-schema";

export const capitalType = (title: string): CompanyResearchBrief["earningsAndCapital"]["capitalActions"][number]["type"] | null => {
  const pairs: Array<[RegExp, CompanyResearchBrief["earningsAndCapital"]["capitalActions"][number]["type"]]> = [
    [/回购/, "回购"],
    [/增持/, "增持"],
    [/减持/, "减持"],
    [/定增|非公开发行/, "定增"],
    [/激励/, "股权激励"],
    [/并购|收购|重组/, "并购"],
    [/资产注入/, "资产注入"],
    [/解禁/, "解禁"],
  ];
  return pairs.find(([pattern]) => pattern.test(title))?.[1] ?? null;
};

export type CapitalActionInput = {
  type: NonNullable<ReturnType<typeof capitalType>>;
  date: string;
  description: string;
  interpretation: string;
};

export const mergeCapitalActions = (items: CapitalActionInput[]): CapitalActionInput[] => {
  const groups = new Map<string, CapitalActionInput[]>();
  for (const item of items) {
    const key = item.type === "回购" ? "回购" : `${item.type}|${item.date}`;
    const group = groups.get(key) ?? [];
    group.push(item);
    groups.set(key, group);
  }
  return [...groups.values()].map((group) => {
    if (group.length === 1) return group[0]!;
    const dates = group.map((item) => item.date).sort();
    return {
      type: group[0]!.type,
      date: dates[0] === dates.at(-1) ? dates[0]! : `${dates[0]}至${dates.at(-1)}`,
      description: group.map((item) => item.description).join("；"),
      interpretation: `${group[0]!.type}相关公告合并为一个资本事件，共${group.length}条公开记录。`,
    };
  });
};
