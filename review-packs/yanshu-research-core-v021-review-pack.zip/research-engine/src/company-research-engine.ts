import {
  CninfoAnnouncementProvider,
  DerivedIndustryProvider,
  EastmoneyCompanyProfileProvider,
  FallbackMarketDataProvider,
  SinaFinancialDataProvider,
  type Announcement,
  type CompanyProfileSnapshot,
  type DailyBar,
  type FinancialSnapshot,
  type IndustrySnapshot,
  type MarketDataProvider,
  type PublicCompanySummary,
  type PublicFeedCompany,
  type ProviderResult,
} from "@yanshu/data-providers";
import { companyResearchBriefSchema, type CompanyResearchBrief } from "@yanshu/research-schema";
import { freshnessFromPublishedAt } from "./evidence/freshness.js";
import { capitalType, mergeCapitalActions } from "./capital/capital-actions.js";
import { financialFact } from "./financial/financial-analysis.js";
import { normalizeEvidence, normalizeFeedFact, normalizeFeedResearch } from "./evidence/normalize.js";
import { selectEvidence } from "./evidence/selector.js";
import type { NormalizedEvidence } from "./evidence/types.js";
import { industryConclusion, industryState } from "./industry/industry-state.js";
import { deriveMarketMetrics, marketStage, type MarketMetrics } from "./market/market-stage.js";
import type { ResearchAvailability, ResearchEngineResult } from "./index.js";

type PublicFeedLike = {
  search(query: string): Promise<PublicCompanySummary[]>;
  company(code: string): Promise<PublicFeedCompany | null>;
};

type LiveProviders = {
  market: MarketDataProvider;
  profile: { profile(code: string): Promise<ProviderResult<unknown>> };
  financial: { reports(code: string): Promise<ProviderResult<unknown>> };
  announcements: { announcements(code: string, since?: string): Promise<ProviderResult<unknown>> };
  industry: { industry(code: string): Promise<ProviderResult<unknown>> };
};

type Clock = () => Date;

const text = (value: unknown, fallback = ""): string => typeof value === "string" && value.trim() ? value.trim() : fallback;
const number = (value: unknown): number | undefined => typeof value === "number" && Number.isFinite(value) ? value : undefined;
const record = (value: unknown): Record<string, unknown> | null => value !== null && typeof value === "object" && !Array.isArray(value) ? value as Record<string, unknown> : null;
const dateTime = (value: string | undefined, fallback: Date): string => {
  if (!value) return fallback.toISOString();
  const parsed = new Date(value);
  return Number.isFinite(parsed.getTime()) ? parsed.toISOString() : fallback.toISOString();
};
const pct = (value: number | undefined): string => value === undefined ? "暂无可靠数据" : `${value >= 0 ? "+" : ""}${value.toFixed(2)}%`;
const amount = (value: number | undefined): string => value === undefined ? "暂无可靠数据" : `${(value / 100000000).toFixed(2)}亿元`;
const cutoffIso = (now: Date): string => new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000).toISOString();

const latestBarDate = (bars: DailyBar[]): string | undefined => bars.at(-1)?.date;

const metricsFact = (metrics: MarketMetrics): string => `近5日${pct(metrics.return5d)}、近10日${pct(metrics.return10d)}、近20日${pct(metrics.return20d)}；最近一日成交量相对前5日均量${metrics.volumeRatio5d === undefined ? "暂无可靠数据" : `${metrics.volumeRatio5d.toFixed(2)}倍`}。`;

const marketCurrentFact = (stage: CompanyResearchBrief["currentView"]["stage"], metrics: MarketMetrics, hasBars: boolean): string => {
  if (!hasBars) return "当前交易层面暂缺足够的近期量价数据。";
  return `当前交易层面为${stage}：近5日${pct(metrics.return5d)}、近20日${pct(metrics.return20d)}，量能相对前5日均量${metrics.volumeRatio5d === undefined ? "暂无可靠数据" : `${metrics.volumeRatio5d.toFixed(2)}倍`}。`;
};

const currentStance = (stage: CompanyResearchBrief["currentView"]["stage"], financial: FinancialSnapshot | null): CompanyResearchBrief["currentView"]["stance"] => {
  if (stage === "退潮") return "中性偏空";
  if (stage === "加速" || stage === "启动") return financial?.netProfitYoY !== undefined && financial.netProfitYoY > 0 ? "中性偏多" : "中性";
  if (stage === "修复" || stage === "二波蓄势") return "中性偏多";
  return "中性";
};

export class CompanyResearchEngine {
  readonly name = "research-core-v0.21";

  constructor(
    private readonly feed: PublicFeedLike,
    private readonly live: LiveProviders = {
      market: new FallbackMarketDataProvider(),
      profile: new EastmoneyCompanyProfileProvider(),
      financial: new SinaFinancialDataProvider(),
      announcements: new CninfoAnnouncementProvider(),
      industry: new DerivedIndustryProvider(new EastmoneyCompanyProfileProvider()),
    },
    private readonly clock: Clock = () => new Date(),
  ) {}

  async search(query: string): Promise<PublicCompanySummary[]> {
    const feedItems = await this.feed.search(query).catch(() => []);
    const normalized = query.trim();
    if (!/^\d{6}$/.test(normalized) || feedItems.some((item) => item.code === normalized)) return feedItems;
    const profile = await this.live.profile.profile(normalized);
    const value = profile.value as CompanyProfileSnapshot | null;
    if (!value) return feedItems;
    return [...feedItems, { code: normalized, name: value.name, industry: value.primaryIndustry, coverage: "public_context", updatedAt: null }];
  }

  async health(): Promise<Record<string, unknown>> {
    return {
      researchEngine: this.name,
      providers: {
        publicFeed: "configured",
        market: this.live.market.name,
        marketSnapshot: "eastmoney-market-sector-snapshot",
        sectorSnapshot: "eastmoney-market-sector-snapshot",
        company: (this.live.profile as { name?: string }).name ?? "configured",
        announcement: (this.live.announcements as { name?: string }).name ?? "configured",
        financial: (this.live.financial as { name?: string }).name ?? "configured",
        industry: (this.live.industry as { name?: string }).name ?? "configured",
      },
    };
  }

  async companyBrief(code: string): Promise<ResearchEngineResult> {
    if (!/^\d{6}$/.test(code)) throw new Error("股票代码必须是六位数字");
    const now = this.clock();
    const [historical, profileResult, quoteResult, klineResult, financialResult, announcementResult, industryResult] = await Promise.all([
      this.feed.company(code).catch(() => null),
      this.live.profile.profile(code),
      this.live.market.quote(code),
      this.live.market.dailyKline(code, 120),
      this.live.financial.reports(code),
      this.live.announcements.announcements(code, cutoffIso(now)),
      this.live.industry.industry(code),
    ]);

    const profile = profileResult.value as CompanyProfileSnapshot | null;
    const quote = quoteResult.value as { name?: string; asOf?: string; price?: number; changePct?: number } | null;
    const bars = (klineResult.value as DailyBar[] | null) ?? [];
    const financial = financialResult.value as FinancialSnapshot | null;
    const announcements = (announcementResult.value as Announcement[] | null) ?? [];
    const industry = (industryResult.value as IndustrySnapshot | null) ?? null;
    const feedProfile = historical?.profile;
    const feedContext = historical?.context;
    const name = profile?.name || quote?.name || text(record(feedProfile)?.name) || text(record(feedContext)?.name) || `证券${code}`;
    const primaryIndustry = profile?.primaryIndustry || text(record(feedProfile)?.industry) || "行业暂未确认";
    const metrics = deriveMarketMetrics(bars);
    const stage = marketStage(metrics);
    const stance = currentStance(stage, financial);
    const currentDataAsOf = quote?.asOf || (latestBarDate(bars) ? dateTime(`${latestBarDate(bars)}T16:00:00+08:00`, now) : undefined);
    const briefAsOf = currentDataAsOf || financialResult.dataAsOf || now.toISOString();
    const historicalItems = [...normalizeFeedResearch(code, feedProfile, now), ...((historical?.facts ?? []).map((fact) => normalizeFeedFact(code, fact, now)).filter((item): item is NormalizedEvidence => item !== null))];
    const currentEvidence: NormalizedEvidence[] = [];
    if (profile) currentEvidence.push(normalizeEvidence({ code, category: "company", title: "公司基础资料", fact: profile.businessSummary || `${profile.name}，所属${profile.primaryIndustry}。`, sourceType: profileResult.source, reliability: "high", currentUsable: true, now }));
    if (industry) currentEvidence.push(normalizeEvidence({ code, category: "industry", title: "所属行业与产业主题", fact: `${industry.primaryIndustry}${industry.themes.length ? `；相关主题：${industry.themes.join("、")}` : ""}。${industry.note ?? ""}`, sourceType: industryResult.source, reliability: "high", currentUsable: true, now }));
    if (quote) currentEvidence.push(normalizeEvidence({ code, category: "market", title: "最新行情", fact: `最新价${quote.price?.toFixed(2) ?? "暂无"}，当日涨跌${pct(quote.changePct)}。`, ...(quote.asOf ? { publishedAt: quote.asOf, dataAsOf: quote.asOf } : {}), sourceType: quoteResult.source, reliability: "high", now }));
    if (bars.length) currentEvidence.push(normalizeEvidence({ code, category: "market", title: "近期量价变化", fact: metricsFact(metrics), ...(currentDataAsOf ? { publishedAt: currentDataAsOf, dataAsOf: currentDataAsOf } : {}), sourceType: klineResult.source, reliability: "high", relevance: 0.9, now }));
    if (financial) currentEvidence.push(normalizeEvidence({ code, category: "financial", title: `最新财报 ${financial.period}`, fact: financialFact(financial), ...(financialResult.dataAsOf ? { publishedAt: financialResult.dataAsOf, dataAsOf: financialResult.dataAsOf } : {}), sourceType: financialResult.source, reliability: "medium", relevance: 0.95, now }));
    for (const announcement of announcements) {
      currentEvidence.push(normalizeEvidence({ code, category: capitalType(announcement.title) ? "capital_action" : "announcement", title: announcement.title, fact: `公告标题：${announcement.title}${announcement.category ? `；类型：${announcement.category}` : ""}`, publishedAt: announcement.publishedAt, ...(announcement.url ? { sourceUrl: announcement.url } : {}), sourceType: announcementResult.source, reliability: "official", relevance: 0.95, now }));
    }
    const allEvidence = [...currentEvidence, ...historicalItems];
    const selected = selectEvidence(allEvidence, { now, maxItems: 5, recentDays: 30 });
    // Company and industry records describe the current profile; they are not events.
    // Keep them in the current view, but do not present them as recent changes.
    const recentChanges = selected
      .filter((item) => item.currentUsable && item.category !== "historical_research" && item.category !== "company" && item.category !== "industry")
      .slice(0, 5);
    const currentIndustryState = industryState(industry);
    const currentIndustryConclusion = industryConclusion(industry);
    const business = profile?.businessSummary || text(record(feedProfile)?.headline) || "公司主营业务暂无可靠公开结构化资料。";
    const marketCurrent = marketCurrentFact(stage, metrics, bars.length > 0);
    const currentLogic = profile && (quote || bars.length || financial)
      ? `${profile.name}属于${profile.primaryIndustry}，当前交易阶段为${stage}。${financial ? `最新财报显示${financial.period}收入${amount(financial.revenue)}、归母净利润${amount(financial.netProfit)}，先看业绩能否支撑估值。` : "最新财报数据不足，基本面暂不下确定结论。"}${marketCurrent}${currentIndustryState === "数据不足" ? "行业层数据不足，暂不把个股表现当作产业强弱。" : `所属行业当日表现为${currentIndustryState}。`}`
      : "当前可获得的公开事实不足，暂不形成确定的公司级判断。";
    const changeItems = recentChanges.map((item) => ({ date: item.publishedAt?.slice(0, 10), category: item.category === "financial" ? "财报" as const : item.category === "capital_action" ? "资本运作" as const : item.category === "industry" ? "产业" as const : item.category === "market" ? "市场" as const : "公司" as const, title: item.title, interpretation: item.fact }));
    const capitalActions = mergeCapitalActions(announcements.map((item) => {
      const type = capitalType(item.title);
      return type ? { type, date: item.publishedAt.slice(0, 10), description: item.title, interpretation: item.category || "公开公告" } : null;
    }).filter((item): item is NonNullable<typeof item> => item !== null));
    const researchAsOf = text(record(feedProfile)?.updatedAt) || text(record(feedContext)?.generatedAt) || undefined;
    const historicalSummary = historicalItems.length ? "历史研究仅用于还原过去的关注原因，不直接替代当前判断。" : "当前没有可用历史研究档案，以下判断只基于本次公开数据。";
    const unavailableScores = { industry: null, fundamentals: null, market: null, tradingStructure: null, opportunity: null };
    const industryDrivers = industry?.boards?.filter((board) => board.changePct !== undefined).slice(0, 5).map((board) => `${board.name}当日${pct(board.changePct)}`) ?? [];
    const briefCandidate = {
      meta: { companyName: name, stockCode: code, exchange: profile?.exchange || (code.startsWith("6") ? "上交所" : "深交所"), asOf: dateTime(briefAsOf, now), dataAsOf: currentDataAsOf ? dateTime(currentDataAsOf, now) : undefined, freshness: freshnessFromPublishedAt(currentDataAsOf, now), primaryIndustry, subIndustries: industry?.themes ?? [] },
      currentView: { stance, currentTradingLogic: currentLogic, stage, summary: `${name}当前处于${stage}阶段；${financial ? `最新财报为${financial.period}，先看业绩兑现。` : "财报数据不足，先看公司公告与市场表现。"}`, scores: unavailableScores },
      companyProfile: { coreBusiness: [business], growthBusiness: [], marketCurrentlyTrading: [marketCurrent], unverifiedNarratives: ["暂无足够公开资料形成券商一致预期和机会评分。"], businessSegments: [{ name: "公司主营", importance: "公开基础资料", growth: "结合最新财报与公告继续确认", marketAttention: `${primaryIndustry}${industry?.themes.length ? `；${industry.themes.join("、")}` : ""}`, conclusion: business }] },
      recentChanges: { window: "最近30天有投资影响的公开事实", changeChain: recentChanges.map((item) => item.fact), majorChanges: changeItems },
      industryProgress: { industryState: currentIndustryState, drivers: industryDrivers, leadingCompanies: [], companyPosition: `${primaryIndustry}${industry?.themes.length ? `；关联方向：${industry.themes.join("、")}` : ""}`, conclusion: currentIndustryConclusion },
      marketPerformance: { return5d: metrics.return5d, return10d: metrics.return10d, return20d: metrics.return20d, relativeStrength: currentIndustryState === "数据不足" ? "行业相对强弱数据不足，暂不比较个股与板块。" : `所属行业当日状态为${currentIndustryState}，公司与行业的中短期相对强弱仍需继续观察。`, volumeAndTurnover: bars.length ? `近5日量比${metrics.volumeRatio5d === undefined ? "暂无可靠数据" : metrics.volumeRatio5d.toFixed(2)}倍；近20日量比${metrics.volumeRatio20d === undefined ? "暂无可靠数据" : metrics.volumeRatio20d.toFixed(2)}倍。` : "暂无可靠日K数据。", capitalFlow: "暂无可核验的个股资金流数据。", sectorPerformance: currentIndustryState === "数据不足" ? "行业表现数据不足，暂不判断行业持续性。" : `所属行业当日表现为${currentIndustryState}。`, summary: bars.length ? `近5日${pct(metrics.return5d)}；近10日${pct(metrics.return10d)}；近20日${pct(metrics.return20d)}。` : "暂无可靠的近期行情数据。", shortTermStage: stage },
      earningsAndCapital: { earnings: { revenueChange: financial?.revenueYoY === undefined ? "暂无可靠数据" : pct(financial.revenueYoY), profitChange: financial?.netProfitYoY === undefined ? "暂无可靠数据" : pct(financial.netProfitYoY), grossMarginChange: financial?.grossMargin === undefined ? "暂无可靠数据" : `毛利率${financial.grossMargin.toFixed(2)}%`, cashFlowChange: financial?.operatingCashFlow === undefined ? "暂无可靠数据" : `经营现金流${amount(financial.operatingCashFlow)}`, actualGrowthDrivers: financial ? [financialFact(financial)] : [], unverifiedExpectations: ["财报数字能够描述结果，但不能仅凭结构化字段确认业务利润来源。"], interpretation: financial ? "当前仅展示结构化财报数字，不把无法拆分的利润驱动写成确定结论。" : "当前无法取得可靠财报结构化数据。" }, capitalActions },
      brokerView: { lookbackDays: 90 as const, interpretation: "暂无足够可靠的券商一致预期或目标价数据。" },
      opportunity: { score: null, components: { industry: null, fundamentals: null, marketCapital: null, tradingStructure: null, valuationRisk: null }, currentConclusion: "当前没有经过回测的机会评分，暂不显示分数。", majorRisk: "当前仍缺行业相对强弱、资金流和券商预期，不能仅凭个股行情推导机会。" },
      changeConditions: { strengthen: ["最新财报继续改善，并能解释收入、利润和现金流的共同变化。", "公司相对所属板块持续走强，且有新的订单、产品或资本动作验证。"], weaken: ["财报或公告出现经营恶化、订单不及预期或资本结构压力。", "放量下跌并进入退潮阶段，同时行业数据也转弱。"] },
      historicalContext: { researchAsOf: researchAsOf ? dateTime(researchAsOf, now) : undefined, summary: historicalSummary, items: historicalItems.map((item) => item.fact).slice(0, 8) },
      evidence: allEvidence,
    };
    const parsed = companyResearchBriefSchema.safeParse(briefCandidate);
    if (!parsed.success) return { availability: "partial" as ResearchAvailability, brief: null, missing: ["CompanyResearchBrief schema 校验失败", ...parsed.error.issues.map((issue) => issue.path.join("."))] };
    return { availability: "ready", brief: parsed.data, missing: [] };
  }
}
