import test from "node:test";
import assert from "node:assert/strict";
import { CompanyResearchEngine } from "../dist/company-research-engine.js";
import { freshnessFromPublishedAt } from "../dist/evidence/freshness.js";
import { normalizeEvidence, isMaterialEvidence } from "../dist/evidence/normalize.js";
import { selectEvidence } from "../dist/evidence/selector.js";
import { marketStage } from "../dist/market/market-stage.js";
import { grossMarginFromOperatingCost, deriveIndustryThemes } from "@yanshu/data-providers";

const now = new Date("2026-08-18T08:00:00.000Z");
const providerResult = (value, source = "test", dataAsOf = "2026-08-18T08:00:00.000Z") => ({ value, source, fetchedAt: now.toISOString(), dataAsOf, status: "ok" });

test("freshness is calculated from evidence date, not feed update time", () => {
  assert.equal(freshnessFromPublishedAt("2026-08-18T08:00:00.000Z", now), "fresh");
  assert.equal(freshnessFromPublishedAt("2026-08-12T08:00:00.000Z", now), "stale");
});

test("stale historical research cannot enter the current evidence selector", () => {
  const historical = normalizeEvidence({ code: "300017", category: "historical_research", title: "旧研究判断", fact: "2026年6月的旧观点", publishedAt: "2026-06-10", sourceType: "GitHub Public Feed", reliability: "medium", currentUsable: false, now });
  const current = normalizeEvidence({ code: "300017", category: "market", title: "当前行情", fact: "截至当前的公开行情", publishedAt: now.toISOString(), sourceType: "Tencent", reliability: "high", currentUsable: true, now });
  const selected = selectEvidence([historical, current], { now, maxItems: 5 });
  assert.equal(selected.some((item) => item.title === "旧研究判断"), true);
  assert.equal(selected.find((item) => item.title === "旧研究判断")?.currentUsable, false);
  assert.equal(selected.find((item) => item.title === "当前行情")?.currentUsable, true);
});

test("procedural announcements are excluded from material changes", () => {
  const routine = normalizeEvidence({ code: "300017", category: "announcement", title: "召开股东大会提示公告", fact: "程序性通知", publishedAt: now.toISOString(), sourceType: "CNINFO", reliability: "official", currentUsable: true, now });
  const material = normalizeEvidence({ code: "300017", category: "announcement", title: "公司发布业绩预告", fact: "业绩变化需要纳入判断", publishedAt: now.toISOString(), sourceType: "CNINFO", reliability: "official", currentUsable: true, now });
  assert.equal(isMaterialEvidence(routine), false);
  assert.equal(isMaterialEvidence(material), true);
});

test("market stage uses multiple price and volume dimensions", () => {
  assert.equal(marketStage({ return5d: 10, return10d: 12, return20d: 20, volumeRatio5d: 1.3, drawdownFromRecentHigh: -1, todayPct: 2, consecutiveUp: 5, consecutiveDown: 0 }), "加速");
  assert.equal(marketStage({ return5d: -5, return10d: -10, return20d: -12, volumeRatio5d: 1.2, drawdownFromRecentHigh: -15, todayPct: -3, consecutiveUp: 0, consecutiveDown: 4 }), "退潮");
});

test("current view is rebuilt from current providers, while old feed stays historical", async () => {
  const bars = Array.from({ length: 120 }, (_, index) => ({
    date: `2026-0${Math.min(7, 1 + Math.floor(index / 30))}-${String((index % 28) + 1).padStart(2, "0")}`,
    open: 10 + index * 0.01,
    high: 10.1 + index * 0.01,
    low: 9.9 + index * 0.01,
    close: 10 + index * 0.01,
    volume: 100 + index,
  }));
  const feed = {
    search: async () => [],
    company: async () => ({
      code: "300017",
      profile: { name: "网宿科技", updatedAt: "2026-07-16", industry: "互联网服务", researchMemory: { currentTension: "旧观点不应直接成为今日结论" } },
      context: { name: "网宿科技", generatedAt: "2026-07-16" },
      facts: [{ title: "旧研究事实", fact: "只作为历史背景", date: "2026-06-10" }],
    }),
  };
  const engine = new CompanyResearchEngine(feed, {
    market: { name: "test-market", quote: async () => providerResult({ code: "300017", name: "网宿科技", price: 10, changePct: 1, asOf: now.toISOString() }), dailyKline: async () => providerResult(bars) },
    profile: { profile: async () => providerResult({ code: "300017", name: "网宿科技", exchange: "深交所", primaryIndustry: "互联网服务", businessSummary: "提供内容分发和云安全服务", source: "test-profile" }) },
    financial: { reports: async () => providerResult({ reportDate: "2026-06-30", period: "2026-06-30", revenue: 100, revenueYoY: 12, netProfit: 20, netProfitYoY: 15, rawAvailableFields: [] }) },
    announcements: { announcements: async () => providerResult([{ code: "300017", title: "召开股东大会提示公告", publishedAt: now.toISOString(), category: "程序" }, { code: "300017", title: "公司发布重大合同公告", publishedAt: now.toISOString(), category: "合同" }]) },
    industry: { industry: async () => providerResult({ code: "300017", primaryIndustry: "互联网服务", themes: ["CDN/边缘计算"], status: "partial", dataAsOf: now.toISOString(), note: "板块数据待补" }) },
  }, () => now);
  const result = await engine.companyBrief("300017");
  assert.equal(result.availability, "ready");
  assert.ok(result.brief);
  assert.equal(result.brief.currentView.currentTradingLogic.includes("旧观点不应直接成为今日结论"), false);
  assert.equal(result.brief.historicalContext.items.some((item) => item.includes("旧观点不应直接成为今日结论")), true);
  assert.equal(result.brief.recentChanges.majorChanges.some((item) => item.title.includes("股东大会提示")), false);
  assert.equal(result.brief.recentChanges.majorChanges.some((item) => item.title.includes("重大合同")), true);
  assert.equal(result.brief.recentChanges.majorChanges.some((item) => item.title.includes("公司基础资料")), false);
  assert.equal(result.brief.recentChanges.majorChanges.some((item) => item.title.includes("所属行业与产业主题")), false);
});

test("v0.21 uses data insufficiency and null instead of fake neutrality or zero scores", async () => {
  const bars = Array.from({ length: 120 }, (_, index) => ({
    date: `2026-0${Math.min(7, 1 + Math.floor(index / 30))}-${String((index % 28) + 1).padStart(2, "0")}`,
    open: 10 + index * 0.01,
    high: 10.1 + index * 0.01,
    low: 9.9 + index * 0.01,
    close: 10 + index * 0.01,
    volume: 100 + index,
  }));
  const feed = { search: async () => [], company: async () => null };
  const result = await new CompanyResearchEngine(feed, {
    market: { name: "test-market", quote: async () => providerResult({ code: "600435", name: "北方导航", price: 10, changePct: 1, asOf: now.toISOString() }), dailyKline: async () => providerResult(bars) },
    profile: { profile: async () => providerResult({ code: "600435", name: "北方导航", exchange: "上交所", primaryIndustry: "通信设备", businessSummary: "导航控制与军工产品" }) },
    financial: { reports: async () => providerResult({ reportDate: "2026-06-30", period: "2026-06-30", revenue: 100, revenueYoY: 2, netProfit: 5, netProfitYoY: 1, rawAvailableFields: [] }) },
    announcements: { announcements: async () => providerResult([
      { code: "600435", title: "回购股份进展公告", publishedAt: now.toISOString(), category: "回购" },
      { code: "600435", title: "回购股份公告", publishedAt: now.toISOString(), category: "回购" },
      { code: "600435", title: "回购股份进展公告（二）", publishedAt: now.toISOString(), category: "回购" },
      { code: "600435", title: "回购股份进展公告（三）", publishedAt: now.toISOString(), category: "回购" },
    ]) },
    industry: { industry: async () => providerResult({ code: "600435", primaryIndustry: "通信设备", themes: ["军工/导航控制"], status: "partial", dataAsOf: now.toISOString(), note: "行业表现待补" }) },
  }, () => now).companyBrief("600435");
  assert.equal(result.brief?.industryProgress.industryState, "数据不足");
  assert.deepEqual(result.brief?.currentView.scores, { industry: null, fundamentals: null, market: null, tradingStructure: null, opportunity: null });
  assert.equal(result.brief?.opportunity.score, null);
  assert.deepEqual(result.brief?.companyProfile.growthBusiness, []);
  assert.notEqual(result.brief?.companyProfile.marketCurrentlyTrading[0], result.brief?.currentView.currentTradingLogic);
  assert.equal(result.brief?.currentView.currentTradingLogic.includes("未稳定接入"), false);
  assert.equal(result.brief?.earningsAndCapital.capitalActions.filter((item) => item.type === "回购").length, 1);
});

test("v0.21 does not infer gross margin from total operating cost", () => {
  assert.equal(grossMarginFromOperatingCost(100, 40), 60);
  assert.equal(grossMarginFromOperatingCost(100, undefined), undefined);
});

test("v0.21 does not map generic communication equipment to optical communications", () => {
  const themes = deriveIndustryThemes("通信设备 导航控制 军工", [{ name: "通信设备", code: "X", changePct: 1 }, { name: "光通信", code: "Y", changePct: 1 }]);
  assert.equal(themes.includes("光通信/光模块"), false);
  assert.equal(themes.includes("军工/导航控制"), true);
});
