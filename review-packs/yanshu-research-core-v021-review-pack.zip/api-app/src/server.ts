import cors from "@fastify/cors";
import Fastify from "fastify";
import { createPublicFeedResearchEngine, UnconfiguredResearchEngine, type ResearchEngine } from "@yanshu/research-engine";
import { apiError } from "@yanshu/research-schema";
import { requestId } from "@yanshu/shared";

const app = Fastify({ logger: process.env.NODE_ENV !== "test" });
const engine: ResearchEngine = process.env.PUBLIC_FEED_ENABLED === "0"
  ? new UnconfiguredResearchEngine()
  : createPublicFeedResearchEngine(process.env.PUBLIC_FEED_BASE_URL);

await app.register(cors, { origin: true });

app.get("/api/v1/health", async () => ({
  service: "yanshu-api",
  status: "ok",
  phase: "research-core-v0.21",
  ...(await engine.health?.() ?? { researchEngine: "unconfigured" }),
  generatedAt: new Date().toISOString(),
}));

app.get<{ Querystring: { q?: string } }>("/api/v1/company/search", async (request) => ({
  query: request.query.q?.trim() || "",
  items: await engine.search(request.query.q?.trim() || ""),
  availability: "ready",
}));

app.get<{ Params: { code: string } }>("/api/v1/company/:code/brief", async (request, reply) => {
  const id = requestId();
  try {
    const result = await engine.companyBrief(request.params.code);
    if (!result.brief) {
      return reply.code(200).send({
        availability: result.availability,
        brief: null,
        missing: result.missing,
        requestId: id,
      });
    }
    return reply.code(200).send(result.brief);
  } catch (error) {
    return reply.code(400).send(apiError("INVALID_REQUEST", error instanceof Error ? error.message : "请求无效", id));
  }
});

app.get("/api/v1/recaps/latest", async (_request, reply) => reply.code(503).send(apiError("RECAP_PROVIDER_NOT_READY", "每日复盘 Feed 适配器尚未接入。", requestId())));
app.get("/api/v1/opportunities", async (_request, reply) => reply.code(503).send(apiError("OPPORTUNITY_PROVIDER_NOT_READY", "机会池研究引擎尚未接入。", requestId())));

const port = Number(process.env.API_PORT || 4318);
await app.listen({ host: "127.0.0.1", port });
