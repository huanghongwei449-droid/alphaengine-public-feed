# Research Core v0.21 Golden Tests

| 检查项 | 结果 |
|---|---|
| industry unavailable -> 数据不足 | 通过 |
| 未配置评分 -> null，不使用0 | 通过 |
| 毛利率只读取营业成本 | 通过 |
| 北方导航不映射光通信/光模块 | 通过 |
| growthBusiness不使用概念标签 | 通过 |
| marketCurrentlyTrading不复制currentTradingLogic | 通过 |
| 回购公告合并为单一资本事件 | 通过 |
| 研究文字无后台工程语言 | 通过 |
| 四家公司真实请求HTTP 200 | 通过 |