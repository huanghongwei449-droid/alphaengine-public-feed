# Stale evidence results

Research Core v0.21: historical Feed evidence remains background-only and cannot replace current provider facts.