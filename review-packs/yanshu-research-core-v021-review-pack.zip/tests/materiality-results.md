# Materiality results

Research Core v0.21: routine governance announcements remain out of major changes; capital actions are grouped by event type.