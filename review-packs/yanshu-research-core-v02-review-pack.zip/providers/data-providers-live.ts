import type {
  AnnouncementProvider,
  CompanyProfileProvider,
  FinancialDataProvider,
  IndustryProvider,
  MarketDataProvider,
  ProviderResult,
} from "./index.js";

export type DailyBar = {
  date: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
};

export type QuoteSnapshot = {
  code: string;
  name: string;
  price: number;
  previousClose?: number | undefined;
  changePct?: number | undefined;
  volume?: number | undefined;
  turnoverPct?: number | undefined;
  asOf: string;
};

export type MarketSnapshot = {
  asOf: string;
  indices: Array<{ code: string; name: string; price?: number | undefined; changePct?: number | undefined }>;
};

export type SectorSnapshot = {
  asOf: string;
  sector?: string | undefined;
  rows: Array<{ code: string; name: string; changePct?: number | undefined; upCount?: number | undefined; downCount?: number | undefined; mainNet?: number | undefined }>;
};

export type CompanyProfileSnapshot = {
  code: string;
  name: string;
  exchange: string;
  primaryIndustry: string;
  secondaryIndustry?: string | undefined;
  businessSummary?: string | undefined;
  businessScope?: string | undefined;
  website?: string | undefined;
  source: string;
};

export type FinancialSnapshot = {
  reportDate: string;
  period: string;
  revenue?: number | undefined;
  revenueYoY?: number | undefined;
  netProfit?: number | undefined;
  netProfitYoY?: number | undefined;
  adjustedProfit?: number | undefined;
  grossMargin?: number | undefined;
  operatingCashFlow?: number | undefined;
  rawAvailableFields: string[];
};

export type Announcement = {
  code: string;
  title: string;
  publishedAt: string;
  url?: string | undefined;
  category?: string | undefined;
};

export type IndustrySnapshot = {
  code: string;
  primaryIndustry: string;
  themes: string[];
  boards?: Array<{ name: string; code: string; changePct?: number | undefined; leader?: string | undefined }>;
  dataAsOf: string | null;
  status: "ok" | "partial" | "unavailable";
  note?: string | undefined;
};

const USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 yanshu-research-core/0.2";

const nowIso = (): string => new Date().toISOString();
const text = (value: unknown): string => typeof value === "string" ? value.trim() : "";
const finite = (value: unknown): number | undefined => {
  const parsed = typeof value === "number" ? value : Number(value);
  return Number.isFinite(parsed) ? parsed : undefined;
};
const marketPrefix = (code: string): "sh" | "sz" => /^(5|6|9)/.test(code) ? "sh" : "sz";
const eastmoneyMarket = (code: string): "0" | "1" => marketPrefix(code) === "sh" ? "1" : "0";
const exchangeName = (code: string): string => marketPrefix(code) === "sh" ? "上交所" : "深交所";

async function getGbkText(url: string, headers: Record<string, string> = {}): Promise<string> {
  const response = await fetch(url, { headers: { "User-Agent": USER_AGENT, ...headers } });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return new TextDecoder("gbk").decode(await response.arrayBuffer());
}

async function getJson(url: string, headers: Record<string, string> = {}): Promise<unknown> {
  const response = await fetch(url, { headers: { "User-Agent": USER_AGENT, ...headers } });
  if (!response.ok) throw new Error(`HTTP ${response.status}`);
  return response.json();
}

const ok = <T>(value: T, source: string, dataAsOf: string | null): ProviderResult<T> => ({ value, source, fetchedAt: nowIso(), dataAsOf, status: "ok" });
const unavailable = <T>(source: string, error: string): ProviderResult<T> => ({ value: null, source, fetchedAt: nowIso(), dataAsOf: null, status: "unavailable", error });

export class TencentMarketDataProvider implements MarketDataProvider {
  readonly name = "tencent-fqkline";

  async quote(code: string): Promise<ProviderResult<QuoteSnapshot>> {
    const symbol = `${marketPrefix(code)}${code}`;
    try {
      const raw = await getGbkText(`https://qt.gtimg.cn/q=${symbol}`);
      const match = raw.match(/="([^"]*)"/);
      const payload = match?.[1];
      if (!payload || payload === "1") return unavailable(this.name, "腾讯行情未匹配到股票代码");
      const fields = payload.split("~");
      const price = finite(fields[3]);
      const previousClose = finite(fields[4]);
      if (!price || !text(fields[2])) return unavailable(this.name, "腾讯行情缺少价格或代码字段");
      const timestamp = fields.find((field) => /^\d{14}$/.test(field));
      const asOf = timestamp ? `${timestamp.slice(0, 4)}-${timestamp.slice(4, 6)}-${timestamp.slice(6, 8)}T${timestamp.slice(8, 10)}:${timestamp.slice(10, 12)}:${timestamp.slice(12, 14)}+08:00` : nowIso();
      return ok({
        code: text(fields[2]) || code,
        name: text(fields[1]) || `证券${code}`,
        price,
        previousClose,
        changePct: price && previousClose ? (price / previousClose - 1) * 100 : undefined,
        volume: finite(fields[6]),
        turnoverPct: finite(fields[40]),
        asOf: new Date(asOf).toISOString(),
      }, this.name, new Date(asOf).toISOString());
    } catch (error) {
      return unavailable(this.name, error instanceof Error ? error.message : "腾讯行情请求失败");
    }
  }

  async dailyKline(code: string, limit: number): Promise<ProviderResult<DailyBar[]>> {
    const symbol = `${marketPrefix(code)}${code}`;
    try {
      const data = await getJson(`https://web.ifzq.gtimg.cn/appstock/app/fqkline/get?param=${symbol},day,,,${Math.max(limit, 60)},qfq`) as Record<string, unknown>;
      const root = (data.data as Record<string, unknown> | undefined)?.[symbol] as Record<string, unknown> | undefined;
      const rawRows = (root?.qfqday ?? root?.day) as unknown;
      const rows = Array.isArray(rawRows) ? rawRows : [];
      const bars = rows.map((row): DailyBar | null => {
        if (!Array.isArray(row) || row.length < 6) return null;
        const values = row.map(finite);
        if (!text(row[0]) || values.slice(1, 6).some((value) => value === undefined)) return null;
        return { date: text(row[0]), open: values[1]!, close: values[2]!, high: values[3]!, low: values[4]!, volume: values[5]! };
      }).filter((row): row is DailyBar => row !== null).slice(-limit);
      if (!bars.length) return unavailable(this.name, "腾讯日K返回空数据");
      const lastBar = bars.at(-1);
      if (!lastBar) return unavailable(this.name, "腾讯日K返回空数据");
      return ok(bars, this.name, new Date(`${lastBar.date}T16:00:00+08:00`).toISOString());
    } catch (error) {
      return unavailable(this.name, error instanceof Error ? error.message : "腾讯日K请求失败");
    }
  }
}

export class YahooMarketDataProvider implements MarketDataProvider {
  readonly name = "yahoo-chart-fallback";

  async quote(code: string): Promise<ProviderResult<QuoteSnapshot>> {
    const result = await this.dailyKline(code, 5);
    const last = result.value?.at(-1);
    const previous = result.value?.at(-2);
    if (!last) return unavailable(this.name, result.error || "Yahoo行情为空");
    return ok({ code, name: `证券${code}`, price: last.close, previousClose: previous?.close, changePct: previous ? (last.close / previous.close - 1) * 100 : undefined, volume: last.volume, asOf: new Date(`${last.date}T16:00:00+08:00`).toISOString() }, this.name, new Date(`${last.date}T16:00:00+08:00`).toISOString());
  }

  async dailyKline(code: string, limit: number): Promise<ProviderResult<DailyBar[]>> {
    const suffix = marketPrefix(code) === "sh" ? ".SS" : ".SZ";
    try {
      const raw = await getJson(`https://query1.finance.yahoo.com/v8/finance/chart/${code}${suffix}?range=2y&interval=1d`) as Record<string, unknown>;
      const result = ((raw.chart as Record<string, unknown>)?.result as Record<string, unknown>[] | undefined)?.[0];
      const timestamps = result?.timestamp as number[] | undefined;
      const quote = ((result?.indicators as Record<string, unknown>)?.quote as Record<string, unknown>[] | undefined)?.[0];
      const open = quote?.open as (number | null)[] | undefined;
      const high = quote?.high as (number | null)[] | undefined;
      const low = quote?.low as (number | null)[] | undefined;
      const close = quote?.close as (number | null)[] | undefined;
      const volume = quote?.volume as (number | null)[] | undefined;
      const bars = (timestamps ?? []).map((timestamp, index): DailyBar | null => {
        const values = [open?.[index], high?.[index], low?.[index], close?.[index], volume?.[index]];
        if (values.some((value) => typeof value !== "number" || !Number.isFinite(value))) return null;
        return { date: new Date(timestamp * 1000).toISOString().slice(0, 10), open: open![index]!, high: high![index]!, low: low![index]!, close: close![index]!, volume: volume![index]! };
      }).filter((row): row is DailyBar => row !== null).slice(-limit);
      if (!bars.length) return unavailable(this.name, "Yahoo日K返回空数据");
      return ok(bars, this.name, new Date(`${bars.at(-1)!.date}T16:00:00+08:00`).toISOString());
    } catch (error) {
      return unavailable(this.name, error instanceof Error ? error.message : "Yahoo日K请求失败");
    }
  }
}

export class FallbackMarketDataProvider implements MarketDataProvider {
  readonly name = "tencent-then-yahoo";

  constructor(private readonly primary = new TencentMarketDataProvider(), private readonly fallback = new YahooMarketDataProvider()) {}

  async quote(code: string): Promise<ProviderResult<QuoteSnapshot>> {
    const primary = await this.primary.quote(code);
    if (primary.value) return primary;
    const fallback = await this.fallback.quote(code);
    return fallback.value ? fallback : { ...fallback, error: `${primary.error || "主源失败"}; ${fallback.error || "备源失败"}` };
  }

  async dailyKline(code: string, limit: number): Promise<ProviderResult<DailyBar[]>> {
    const primary = await this.primary.dailyKline(code, limit);
    if (primary.value && primary.value.length >= Math.min(limit, 60)) return primary;
    const fallback = await this.fallback.dailyKline(code, limit);
    return fallback.value ? fallback : { ...fallback, error: `${primary.error || "主源失败"}; ${fallback.error || "备源失败"}` };
  }

  async marketSnapshot(): Promise<ProviderResult<unknown>> {
    return new EastmoneySnapshotProvider().marketSnapshot();
  }

  async sectorSnapshot(sector?: string): Promise<ProviderResult<unknown>> {
    return new EastmoneySnapshotProvider().sectorSnapshot(sector);
  }
}

export class EastmoneySnapshotProvider implements MarketDataProvider {
  readonly name = "eastmoney-market-sector-snapshot";

  async quote(code: string): Promise<ProviderResult<unknown>> {
    return unavailable(this.name, "快照提供器不承担个股行情，请使用腾讯行情提供器");
  }

  async dailyKline(_code: string, _limit: number): Promise<ProviderResult<unknown>> {
    return unavailable(this.name, "快照提供器不承担日K，请使用腾讯日K提供器");
  }

  async marketSnapshot(): Promise<ProviderResult<MarketSnapshot>> {
    try {
      const asOf = nowIso();
      const payload = await getJson("https://push2.eastmoney.com/api/qt/ulist.np/get?fltt=2&invt=2&fields=f2,f3,f12,f14&secids=1.000001,0.399001,0.399006,1.000688") as Record<string, unknown>;
      const diff = ((payload.data as Record<string, unknown> | undefined)?.diff) as Record<string, Record<string, unknown>> | Record<string, unknown>[] | undefined;
      const rows = Array.isArray(diff) ? diff : Object.values(diff ?? {});
      const indices = rows.map((row) => ({ code: text(row.f12), name: text(row.f14), ...(finite(row.f2) !== undefined ? { price: finite(row.f2) } : {}), ...(finite(row.f3) !== undefined ? { changePct: finite(row.f3) } : {}) })).filter((row) => row.code && row.name);
      if (!indices.length) return unavailable(this.name, "东财指数快照返回空数据");
      return ok({ asOf, indices }, this.name, asOf);
    } catch (error) {
      return unavailable(this.name, error instanceof Error ? error.message : "东财指数快照请求失败");
    }
  }

  async sectorSnapshot(sector?: string): Promise<ProviderResult<SectorSnapshot>> {
    try {
      const asOf = nowIso();
      const params = "pn=1&pz=100&po=1&np=1&fid=f3&fltt=2&invt=2&fs=m:90+t:2&fields=f3,f12,f14,f104,f105,f62,f128";
      const payload = await getJson(`https://push2.eastmoney.com/api/qt/clist/get?${params}`) as Record<string, unknown>;
      const diff = ((payload.data as Record<string, unknown> | undefined)?.diff) as Record<string, Record<string, unknown>> | Record<string, unknown>[] | undefined;
      const rows = Array.isArray(diff) ? diff : Object.values(diff ?? {});
      const parsed = rows.map((row) => ({ code: text(row.f12), name: text(row.f14), ...(finite(row.f3) !== undefined ? { changePct: finite(row.f3) } : {}), ...(finite(row.f104) !== undefined ? { upCount: finite(row.f104) } : {}), ...(finite(row.f105) !== undefined ? { downCount: finite(row.f105) } : {}), ...(finite(row.f62) !== undefined ? { mainNet: finite(row.f62) } : {}) })).filter((row) => row.code && row.name).filter((row) => !sector || row.name.includes(sector));
      if (!parsed.length) return unavailable(this.name, sector ? `未匹配到行业板块：${sector}` : "东财行业板块快照返回空数据");
      return ok({ asOf, ...(sector ? { sector } : {}), rows: parsed }, this.name, asOf);
    } catch (error) {
      return unavailable(this.name, error instanceof Error ? error.message : "东财行业板块快照请求失败");
    }
  }
}

export class EastmoneyCompanyProfileProvider implements CompanyProfileProvider {
  readonly name = "eastmoney-company-survey";

  async profile(code: string): Promise<ProviderResult<CompanyProfileSnapshot>> {
    try {
      const exchange = exchangeName(code);
      const prefix = marketPrefix(code).toUpperCase();
      const survey = await getJson(`https://emweb.securities.eastmoney.com/PC_HSF10/CompanySurvey/CompanySurveyAjax?code=${prefix}${code}`) as Record<string, unknown>;
      const base = survey.jbzl as Record<string, unknown> | undefined;
      let quoteData: Record<string, unknown> | undefined;
      if (!text(base?.agjc) || !text(base?.sshy)) {
        try {
          const fallback = await getJson(`https://push2.eastmoney.com/api/qt/stock/get?secid=${eastmoneyMarket(code)}.${code}&fields=f57%2Cf58%2Cf127%2Cf43`) as Record<string, unknown>;
          quoteData = fallback.data as Record<string, unknown> | undefined;
        } catch {
          quoteData = undefined;
        }
      }
      const name = text(base?.agjc) || text(quoteData?.f58) || `证券${code}`;
      const primaryIndustry = text(base?.sshy) || text(quoteData?.f127) || "行业暂未确认";
      const value: CompanyProfileSnapshot = {
        code,
        name,
        exchange,
        primaryIndustry,
        secondaryIndustry: text(base?.sszjhhy) || undefined,
        businessSummary: text(base?.gsjj) || undefined,
        businessScope: text(base?.jyfw) || undefined,
        website: text(base?.gswz) || undefined,
        source: this.name,
      };
      return ok(value, this.name, null);
    } catch (error) {
      return unavailable(this.name, error instanceof Error ? error.message : "公司基础资料请求失败");
    }
  }
}

const reportRows = (payload: unknown): Record<string, unknown>[] => {
  const result = payload as Record<string, unknown>;
  const data = (result.result as Record<string, unknown> | undefined)?.data as Record<string, unknown> | undefined;
  const reportList = data?.report_list as Record<string, Record<string, unknown>> | undefined;
  return Object.entries(reportList ?? {}).sort(([a], [b]) => b.localeCompare(a)).map(([period, value]) => ({ period, ...(value.data && typeof value.data === "object" ? { items: value.data } : {}) }));
};

const findItem = (row: Record<string, unknown> | undefined, names: string[]): Record<string, unknown> | undefined => {
  if (!row) return undefined;
  const items = Array.isArray(row.items) ? row.items as Record<string, unknown>[] : [];
  return items.find((item) => names.includes(text(item.item_title)));
};

const itemNumber = (row: Record<string, unknown> | undefined, names: string[]): number | undefined => finite(findItem(row, names)?.item_value);
const itemPercent = (row: Record<string, unknown> | undefined, names: string[]): number | undefined => {
  const value = finite(findItem(row, names)?.item_tongbi);
  return value === undefined ? undefined : value * 100;
};

export class SinaFinancialDataProvider implements FinancialDataProvider {
  readonly name = "sina-financial-report";

  async reports(code: string): Promise<ProviderResult<FinancialSnapshot>> {
    try {
      const prefix = marketPrefix(code);
      const query = (type: string) => getJson(`https://quotes.sina.cn/cn/api/openapi.php/CompanyFinanceService.getFinanceReport2022?paperCode=${prefix}${code}&source=${type}&type=0&page=1&num=8`);
      const [income, cash] = await Promise.all([query("lrb"), query("llb")]);
      const incomeRows = reportRows(income);
      const cashRows = reportRows(cash);
      const latest = incomeRows[0];
      if (!latest) return unavailable(this.name, "新浪财报没有可解析的报告期");
      const period = text(latest.period);
      const revenue = itemNumber(latest, ["营业总收入", "营业收入"]);
      const cost = itemNumber(latest, ["营业总成本", "营业总成本"]);
      const grossMargin = revenue !== undefined && cost !== undefined && revenue !== 0 ? (revenue - cost) / revenue * 100 : undefined;
      const cashRow = cashRows.find((row) => text(row.period) === period) ?? cashRows[0];
      const value: FinancialSnapshot = {
        reportDate: period.length === 8 ? `${period.slice(0, 4)}-${period.slice(4, 6)}-${period.slice(6, 8)}` : period,
        period: period.length === 8 ? `${period.slice(0, 4)}-${period.slice(4, 6)}-${period.slice(6, 8)}` : period,
        revenue,
        revenueYoY: itemPercent(latest, ["营业总收入", "营业收入"]),
        netProfit: itemNumber(latest, ["归属于母公司所有者的净利润", "归属于母公司股东的净利润", "净利润"]),
        netProfitYoY: itemPercent(latest, ["归属于母公司所有者的净利润", "归属于母公司股东的净利润", "净利润"]),
        adjustedProfit: itemNumber(latest, ["扣除非经常性损益后的净利润"]),
        grossMargin,
        operatingCashFlow: itemNumber(cashRow, ["经营活动产生的现金流量净额"]),
        rawAvailableFields: (Array.isArray(latest.items) ? latest.items as Record<string, unknown>[] : []).map((item) => text(item.item_title)).filter(Boolean),
      };
      return ok(value, this.name, new Date(`${value.reportDate}T23:59:59+08:00`).toISOString());
    } catch (error) {
      return unavailable(this.name, error instanceof Error ? error.message : "新浪财报请求失败");
    }
  }
}

export class CninfoAnnouncementProvider implements AnnouncementProvider {
  readonly name = "cninfo-announcement";
  private orgMapPromise: Promise<Map<string, string>> | null = null;

  private orgMap(): Promise<Map<string, string>> {
    if (!this.orgMapPromise) {
      this.orgMapPromise = getJson("https://www.cninfo.com.cn/new/data/szse_stock.json")
        .then((payload) => {
          const rows = Array.isArray((payload as Record<string, unknown>).stockList) ? (payload as Record<string, unknown>).stockList as Record<string, unknown>[] : [];
          const entries: Array<[string, string]> = rows
            .map((row): [string, string] => [text(row.code), text(row.orgId)])
            .filter(([code, org]) => Boolean(code && org));
          return new Map<string, string>(entries);
        })
        .catch(() => new Map<string, string>());
    }
    return this.orgMapPromise!;
  }

  async announcements(code: string, since?: string): Promise<ProviderResult<Announcement[]>> {
    try {
      const org = (await this.orgMap()).get(code) || (marketPrefix(code) === "sh" ? `gssh0${code}` : `gssz0${code}`);
      const body = new URLSearchParams({ stock: `${code},${org}`, tabName: "fulltext", pageSize: "30", pageNum: "1", column: "", category: "", plate: "", seDate: "", searchkey: "", secid: "", sortName: "", sortType: "", isHLtitle: "true" });
      const response = await fetch("https://www.cninfo.com.cn/new/hisAnnouncement/query", { method: "POST", headers: { "User-Agent": USER_AGENT, Referer: "https://www.cninfo.com.cn/new/disclosure", Origin: "https://www.cninfo.com.cn", "Content-Type": "application/x-www-form-urlencoded" }, body });
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const data = await response.json() as Record<string, unknown>;
      const rows = Array.isArray(data.announcements) ? data.announcements as Record<string, unknown>[] : [];
      const items = rows.map((row): Announcement => ({ code, title: text(row.announcementTitle), publishedAt: new Date(Number(row.announcementTime) || 0).toISOString(), category: text(row.announcementTypeName) || undefined, url: `https://www.cninfo.com.cn/new/disclosure/detail?annoId=${text(row.announcementId)}` })).filter((item) => item.title && (!since || item.publishedAt >= since));
      return ok(items, this.name, items[0]?.publishedAt ?? null);
    } catch (error) {
      return unavailable(this.name, error instanceof Error ? error.message : "巨潮公告请求失败");
    }
  }
}

const themeRules: Array<[RegExp, string]> = [
  [/CDN|边缘计算|云分发|云安全|云计算|互联网服务/, "CDN/边缘计算"],
  [/光通信|光模块|通讯行业|通信设备|光电子/, "光通信/光模块"],
  [/汽车|铝合金|工业金属|有色金属/, "汽车材料/铝合金"],
  [/军工|导航|制导|弹药|保军|通信设备/, "军工/导航控制"],
  [/半导体|芯片|集成电路|电子设备/, "半导体/电子设备"],
];

export class DerivedIndustryProvider implements IndustryProvider {
  readonly name = "company-profile-industry-map";

  constructor(private readonly profileProvider: CompanyProfileProvider = new EastmoneyCompanyProfileProvider()) {}

  async industry(code: string): Promise<ProviderResult<IndustrySnapshot>> {
    const profile = await this.profileProvider.profile(code);
    if (!profile.value) return unavailable(this.name, profile.error || "公司基础资料不可用");
    const profileValue = profile.value as CompanyProfileSnapshot;
    const sourceText = `${profileValue.primaryIndustry} ${profileValue.secondaryIndustry ?? ""} ${profileValue.businessSummary ?? ""}`;
    let boards: IndustrySnapshot["boards"] = [];
    try {
      const market = eastmoneyMarket(code);
      const payload = await getJson(`https://push2.eastmoney.com/api/qt/slist/get?fltt=2&invt=2&secid=${market}.${code}&spt=3&pi=0&pz=200&po=1&fields=f12,f14,f3,f128`) as Record<string, unknown>;
      const diff = ((payload.data as Record<string, unknown> | undefined)?.diff) as Record<string, Record<string, unknown>> | Record<string, unknown>[] | undefined;
      const rows = Array.isArray(diff) ? diff : Object.values(diff ?? {});
      boards = rows.map((row) => ({
        name: text(row.f14),
        code: text(row.f12),
        ...(finite(row.f3) !== undefined ? { changePct: finite(row.f3) } : {}),
        ...(text(row.f128) ? { leader: text(row.f128) } : {}),
      })).filter((row) => row.name);
    } catch {
      boards = [];
    }
    const isResearchTheme = (name: string): boolean => !/(板块|深股通|沪股通|中证|深成|创业板综|创业成份|上证|深证|融资融券|转债|MSCI|富时|HS300|AH股|基金重仓|机构重仓|证金持股|昨日高振幅|小盘股|央国企改革|^20\d{2}中报)/.test(name);
    const themes = [...new Set([
      ...themeRules.filter(([pattern]) => pattern.test(sourceText)).map(([, theme]) => theme),
      ...boards.slice(0, 20).map((board) => board.name).filter(isResearchTheme),
    ])];
    return ok({ code, primaryIndustry: profileValue.primaryIndustry, themes, boards, dataAsOf: profile.dataAsOf, status: "partial", note: boards.length ? "已取得公司所属板块与概念映射；板块5/10/20日相对强弱和资金快照仍未稳定接入。" : "已确认公司所属行业和主题映射；板块级实时行情与资金快照暂未取得。" }, this.name, profile.dataAsOf);
  }
}
