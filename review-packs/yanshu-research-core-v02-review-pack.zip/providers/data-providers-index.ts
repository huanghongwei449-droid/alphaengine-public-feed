export type ProviderResult<T> = {
  value: T | null;
  source: string;
  fetchedAt: string;
  dataAsOf: string | null;
  status: "ok" | "partial" | "unavailable";
  error?: string;
};

export interface MarketDataProvider {
  readonly name: string;
  quote(code: string): Promise<ProviderResult<unknown>>;
  dailyKline(code: string, limit: number): Promise<ProviderResult<unknown>>;
  marketSnapshot?(): Promise<ProviderResult<unknown>>;
  sectorSnapshot?(sector?: string): Promise<ProviderResult<unknown>>;
}

export interface CompanyProfileProvider {
  readonly name: string;
  profile(code: string): Promise<ProviderResult<unknown>>;
}

export interface FinancialDataProvider {
  readonly name: string;
  reports(code: string): Promise<ProviderResult<unknown>>;
}

export interface AnnouncementProvider {
  readonly name: string;
  announcements(code: string, since?: string): Promise<ProviderResult<unknown>>;
}

export interface NewsProvider {
  readonly name: string;
  news(code: string, since?: string): Promise<ProviderResult<unknown>>;
}

export interface BrokerResearchProvider {
  readonly name: string;
  reports(code: string, since?: string): Promise<ProviderResult<unknown>>;
}

export interface CapitalFlowProvider {
  readonly name: string;
  flow(code: string, windowDays: number): Promise<ProviderResult<unknown>>;
}

export interface IndustryProvider {
  readonly name: string;
  industry(code: string): Promise<ProviderResult<unknown>>;
}

export { PublicFeedProvider } from "./public-feed.js";
export type { PublicCompanySummary, PublicFeedCompany } from "./public-feed.js";
export * from "./live.js";
