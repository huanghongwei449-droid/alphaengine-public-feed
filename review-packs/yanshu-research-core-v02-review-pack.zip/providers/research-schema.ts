import { z } from "zod";

export const stanceSchema = z.enum(["偏多", "中性偏多", "中性", "中性偏空", "偏空"]);
export const stageSchema = z.enum(["启动", "加速", "分歧", "修复", "横盘", "二波蓄势", "退潮"]);
export const industryStateSchema = z.enum(["增强", "偏强", "中性", "转弱", "退潮"]);
export const changeCategorySchema = z.enum(["产业", "公司", "财报", "资本运作", "市场"]);
export const evidenceCategorySchema = z.enum(["company", "industry", "market", "financial", "announcement", "capital_action", "broker", "news", "historical_research"]);
export const evidenceReliabilitySchema = z.enum(["official", "high", "medium", "low"]);
export const evidenceFreshnessSchema = z.enum(["fresh", "aging", "stale", "unknown"]);

const scoreSchema = z.number().int().min(0).max(100);

export const companyResearchBriefSchema = z.object({
  meta: z.object({
    companyName: z.string().min(1),
    stockCode: z.string().regex(/^\d{6}$/),
    exchange: z.string().optional(),
    asOf: z.string().datetime(),
    dataAsOf: z.string().datetime().optional(),
    freshness: z.enum(["fresh", "aging", "stale", "unknown"]),
    primaryIndustry: z.string().min(1),
    subIndustries: z.array(z.string()),
  }),
  currentView: z.object({
    stance: stanceSchema,
    currentTradingLogic: z.string().min(1),
    stage: stageSchema,
    summary: z.string().min(1),
    scores: z.object({
      industry: scoreSchema,
      fundamentals: scoreSchema,
      market: scoreSchema,
      tradingStructure: scoreSchema,
      opportunity: scoreSchema,
    }),
  }),
  companyProfile: z.object({
    coreBusiness: z.array(z.string()),
    growthBusiness: z.array(z.string()),
    marketCurrentlyTrading: z.array(z.string()),
    unverifiedNarratives: z.array(z.string()),
    businessSegments: z.array(z.object({
      name: z.string(),
      importance: z.string(),
      growth: z.string(),
      marketAttention: z.string(),
      conclusion: z.string(),
    })),
  }),
  recentChanges: z.object({
    window: z.string(),
    changeChain: z.array(z.string()),
    majorChanges: z.array(z.object({
      date: z.string().optional(),
      category: changeCategorySchema,
      title: z.string(),
      interpretation: z.string(),
    })),
  }),
  industryProgress: z.object({
    industryState: industryStateSchema,
    drivers: z.array(z.string()),
    leadingCompanies: z.array(z.string()),
    companyPosition: z.string(),
    conclusion: z.string(),
  }),
  marketPerformance: z.object({
    return5d: z.number().optional(),
    return10d: z.number().optional(),
    return20d: z.number().optional(),
    relativeStrength: z.string().optional(),
    volumeAndTurnover: z.string().optional(),
    capitalFlow: z.string().optional(),
    sectorPerformance: z.string().optional(),
    summary: z.string(),
    shortTermStage: stageSchema,
  }),
  earningsAndCapital: z.object({
    earnings: z.object({
      revenueChange: z.string().optional(),
      profitChange: z.string().optional(),
      grossMarginChange: z.string().optional(),
      cashFlowChange: z.string().optional(),
      actualGrowthDrivers: z.array(z.string()),
      unverifiedExpectations: z.array(z.string()),
      interpretation: z.string(),
    }).optional(),
    capitalActions: z.array(z.object({
      type: z.enum(["回购", "增持", "减持", "定增", "股权激励", "并购", "资产注入", "解禁", "其他"]),
      date: z.string().optional(),
      description: z.string(),
      interpretation: z.string(),
    })),
  }),
  brokerView: z.object({
    lookbackDays: z.literal(90),
    coverageCount: z.number().int().nonnegative().optional(),
    consensus: z.string().optional(),
    earningsRevision: z.string().optional(),
    targetPriceRange: z.string().optional(),
    disagreement: z.string().optional(),
    interpretation: z.string(),
  }),
  opportunity: z.object({
    score: z.number().int().min(0).max(100),
    components: z.object({
      industry: z.number().int().min(0).max(25),
      fundamentals: z.number().int().min(0).max(20),
      marketCapital: z.number().int().min(0).max(20),
      tradingStructure: z.number().int().min(0).max(25),
      valuationRisk: z.number().int().min(0).max(10),
    }),
    currentConclusion: z.string(),
    betterSetup: z.string().optional(),
    majorRisk: z.string().optional(),
  }),
  changeConditions: z.object({
    strengthen: z.array(z.string()),
    weaken: z.array(z.string()),
  }),
  historicalContext: z.object({
    researchAsOf: z.string().datetime().optional(),
    summary: z.string(),
    items: z.array(z.string()),
  }).optional(),
  evidence: z.array(z.object({
    id: z.string().min(1),
    code: z.string().regex(/^\d{6}$/).optional(),
    category: evidenceCategorySchema,
    title: z.string().min(1),
    fact: z.string().min(1),
    publishedAt: z.string().datetime().optional(),
    fetchedAt: z.string().datetime(),
    dataAsOf: z.string().datetime().optional(),
    sourceType: z.string().min(1),
    sourceUrl: z.string().url().optional(),
    reliability: evidenceReliabilitySchema,
    freshness: evidenceFreshnessSchema,
    relevance: z.number().min(0).max(1),
    currentUsable: z.boolean(),
  })).optional(),
});

export const apiErrorSchema = z.object({
  error: z.object({
    code: z.string(),
    message: z.string(),
    requestId: z.string(),
  }),
});

export type CompanyResearchBrief = z.infer<typeof companyResearchBriefSchema>;
export type ApiError = z.infer<typeof apiErrorSchema>;

export const apiError = (code: string, message: string, requestId: string): ApiError => ({
  error: { code, message, requestId },
});
