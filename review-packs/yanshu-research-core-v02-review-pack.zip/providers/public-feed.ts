export type PublicCompanySummary = {
  code: string;
  name: string;
  industry: string;
  coverage: "deep_research" | "public_context" | "unknown";
  updatedAt: string | null;
};

export type PublicFeedCompany = {
  code: string;
  profile: Record<string, unknown> | null;
  context: Record<string, unknown> | null;
  dossier: Record<string, unknown> | null;
  facts: Record<string, unknown>[];
};

type PublicFeedSnapshot = {
  generatedAt: string;
  asOfDate: string;
  profiles: Record<string, unknown>[];
  contexts: Record<string, unknown>[];
  dossiers: Record<string, unknown>[];
  facts: Record<string, unknown>[];
};

const record = (value: unknown): Record<string, unknown> | null =>
  value !== null && typeof value === "object" && !Array.isArray(value)
    ? value as Record<string, unknown>
    : null;

const records = (value: unknown, key: string): Record<string, unknown>[] => {
  const root = record(value);
  const items = Array.isArray(root?.[key]) ? root[key] : Array.isArray(value) ? value : [];
  return items.map(record).filter((item): item is Record<string, unknown> => item !== null);
};

const text = (value: unknown): string => typeof value === "string" ? value : "";

export class PublicFeedProvider {
  readonly name = "github-public-feed";
  private snapshotPromise: Promise<PublicFeedSnapshot> | null = null;

  constructor(
    private readonly baseUrl = "https://raw.githubusercontent.com/huanghongwei449-droid/alphaengine-public-feed/main",
  ) {}

  private async json(path: string): Promise<unknown> {
    const response = await fetch(`${this.baseUrl.replace(/\/$/, "")}/${path}`);
    if (!response.ok) throw new Error(`Public Feed ${path} HTTP ${response.status}`);
    return response.json();
  }

  private snapshot(): Promise<PublicFeedSnapshot> {
    if (!this.snapshotPromise) {
      this.snapshotPromise = Promise.all([
        this.json("feed-manifest.json"),
        this.json("data/company-research-profiles.json"),
        this.json("data/company-public-context.json"),
        this.json("data/company-public-dossiers.json"),
        this.json("data/company-fact-evidence.json"),
      ]).then(([manifest, profiles, contexts, dossiers, facts]) => {
        const manifestRecord = record(manifest);
        return {
          generatedAt: text(manifestRecord?.generatedAt),
          asOfDate: text(manifestRecord?.asOfDate),
          profiles: records(profiles, "profiles"),
          contexts: records(contexts, "companies"),
          dossiers: records(dossiers, "dossiers"),
          facts: records(facts, "evidence"),
        };
      });
    }
    return this.snapshotPromise;
  }

  async search(query: string): Promise<PublicCompanySummary[]> {
    const normalized = query.trim().toLowerCase();
    if (!normalized) return [];
    const snapshot = await this.snapshot();
    const byCode = new Map<string, PublicCompanySummary>();

    for (const item of snapshot.profiles) {
      const code = text(item.code);
      const name = text(item.name);
      if (!code || !name) continue;
      const matches = code.includes(normalized) || name.toLowerCase().includes(normalized);
      if (!matches) continue;
      byCode.set(code, {
        code,
        name,
        industry: text(record(item.business)?.chainPosition) || "未分类",
        coverage: item.profileLevel === "deep_research" ? "deep_research" : "public_context",
        updatedAt: text(item.updatedAt) || null,
      });
    }

    for (const item of snapshot.contexts) {
      const code = text(item.code);
      const name = text(item.name);
      if (!code || !name || (!code.includes(normalized) && !name.toLowerCase().includes(normalized))) continue;
      if (!byCode.has(code)) {
        byCode.set(code, { code, name, industry: "未分类", coverage: "public_context", updatedAt: text(item.generatedAt) || null });
      }
    }

    return [...byCode.values()].slice(0, 20);
  }

  async company(code: string): Promise<PublicFeedCompany | null> {
    const snapshot = await this.snapshot();
    const byCode = (items: Record<string, unknown>[]) => items.find((item) => text(item.code) === code) ?? null;
    const facts = snapshot.facts.filter((item) => {
      const stocks = item.relatedStocks ?? item.related_stocks;
      return Array.isArray(stocks) && stocks.some((stock) => text(stock) === code);
    });
    const profile = byCode(snapshot.profiles);
    const context = byCode(snapshot.contexts);
    const dossier = byCode(snapshot.dossiers);
    if (!profile && !context && !dossier) return null;
    return { code, profile, context, dossier, facts };
  }

  async metadata(): Promise<{ generatedAt: string; asOfDate: string }> {
    const snapshot = await this.snapshot();
    return { generatedAt: snapshot.generatedAt, asOfDate: snapshot.asOfDate };
  }
}
