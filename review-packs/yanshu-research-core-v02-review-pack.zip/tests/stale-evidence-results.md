# Stale Evidence Results

- 给定当前时间 `2026-08-18`，`2026-06-10` 的短线判断被标记为 `stale`。
- 该判断只进入 `historicalContext`，`currentUsable=false`，不会进入当前交易逻辑或最近变化。
- GitHub Feed 的更新时间没有被当作历史研究内容的新鲜度。

结果：通过。
