# Anti-Garbage Results

测试确保当前简报不把以下后台语言作为研究结论输出：

- 找到多少条资料
- product public fact
- IMA historical recap
- 群聊围观
- 最近一晚新增
- 公开 Feed 已收录的近期路径与公司事件

旧 Feed 只在 `historicalContext` 中保留研究背景；当前 `currentView` 从实时公开资料、行情、财报和公告重新综合。

结果：通过。
