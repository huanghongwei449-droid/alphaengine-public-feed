import type { DailyBar } from "@yanshu/data-providers";

export type MarketMetrics = {
  return5d?: number | undefined;
  return10d?: number | undefined;
  return20d?: number | undefined;
  return60d?: number | undefined;
  todayPct?: number | undefined;
  volumeRatio5d?: number | undefined;
  volumeRatio20d?: number | undefined;
  distanceFrom20dHigh?: number | undefined;
  distanceFrom60dHigh?: number | undefined;
  drawdownFromRecentHigh?: number | undefined;
  consecutiveUp: number;
  consecutiveDown: number;
};

const changeFrom = (bars: DailyBar[], days: number): number | undefined => {
  if (bars.length <= days) return undefined;
  const previousBar = bars[bars.length - 1 - days];
  const previous = previousBar?.close;
  const latest = bars.at(-1)?.close;
  return previous && latest ? (latest / previous - 1) * 100 : undefined;
};

const average = (values: number[]): number | undefined => values.length ? values.reduce((sum, value) => sum + value, 0) / values.length : undefined;

export const deriveMarketMetrics = (bars: DailyBar[]): MarketMetrics => {
  const latest = bars.at(-1);
  const previous = bars.at(-2);
  const last20 = bars.slice(-20);
  const last60 = bars.slice(-60);
  const prior5Volumes = bars.slice(-6, -1).map((bar) => bar.volume);
  const prior20Volumes = bars.slice(-21, -1).map((bar) => bar.volume);
  const high20 = Math.max(...last20.map((bar) => bar.close), 0);
  const high60 = Math.max(...last60.map((bar) => bar.close), 0);
  let consecutiveUp = 0;
  let consecutiveDown = 0;
  for (let index = bars.length - 1; index > 0; index -= 1) {
    const current = bars[index];
    const previous = bars[index - 1];
    if (!current || !previous) break;
    if (current.close > previous.close && consecutiveDown === 0) consecutiveUp += 1;
    else if (current.close < previous.close && consecutiveUp === 0) consecutiveDown += 1;
    else break;
  }
  const recentHigh = Math.max(...bars.slice(-30).map((bar) => bar.close), 0);
  return {
    return5d: changeFrom(bars, 5),
    return10d: changeFrom(bars, 10),
    return20d: changeFrom(bars, 20),
    return60d: changeFrom(bars, 60),
    todayPct: latest && previous ? (latest.close / previous.close - 1) * 100 : undefined,
    volumeRatio5d: latest && average(prior5Volumes) ? latest.volume / average(prior5Volumes)! : undefined,
    volumeRatio20d: latest && average(prior20Volumes) ? latest.volume / average(prior20Volumes)! : undefined,
    distanceFrom20dHigh: latest && high20 ? (latest.close / high20 - 1) * 100 : undefined,
    distanceFrom60dHigh: latest && high60 ? (latest.close / high60 - 1) * 100 : undefined,
    drawdownFromRecentHigh: latest && recentHigh ? (latest.close / recentHigh - 1) * 100 : undefined,
    consecutiveUp,
    consecutiveDown,
  };
};

export const marketStage = (metrics: MarketMetrics): "启动" | "加速" | "分歧" | "修复" | "横盘" | "二波蓄势" | "退潮" => {
  const r5 = metrics.return5d ?? 0;
  const r10 = metrics.return10d ?? 0;
  const r20 = metrics.return20d ?? 0;
  const volume = metrics.volumeRatio5d ?? 1;
  const drawdown = metrics.drawdownFromRecentHigh ?? 0;
  const today = metrics.todayPct ?? 0;
  if (metrics.consecutiveDown >= 3 && r10 <= -8 && (volume >= 1 || r20 <= -5)) return "退潮";
  if (r5 >= 8 && r10 >= 10 && volume >= 1.15) return "加速";
  if (r5 >= 3 && r10 >= 2 && volume >= 1.1 && r20 > 0) return "启动";
  if (drawdown <= -8 && r5 > 0 && r10 > -5) return "修复";
  if (r20 >= 8 && drawdown < -3 && drawdown > -15 && Math.abs(r5) < 6 && volume <= 1.25) return "二波蓄势";
  if (Math.abs(today) >= 4 || (Math.abs(r5) <= 3 && Math.abs(r10) >= 8)) return "分歧";
  return "横盘";
};
