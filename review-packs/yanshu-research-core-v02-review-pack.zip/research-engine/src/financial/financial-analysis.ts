import type { FinancialSnapshot } from "@yanshu/data-providers";

const amount = (value: number | undefined): string => value === undefined ? "暂无可靠数据" : `${(value / 100000000).toFixed(2)}亿元`;
const pct = (value: number | undefined): string => value === undefined ? "暂无可靠数据" : `${value >= 0 ? "+" : ""}${value.toFixed(2)}%`;

export const financialFact = (value: FinancialSnapshot | null): string => {
  if (!value) return "最新财报结构化数据暂无可靠读取。";
  return `最新报告期${value.period}：营业收入${amount(value.revenue)}（同比${pct(value.revenueYoY)}），归母净利润${amount(value.netProfit)}（同比${pct(value.netProfitYoY)}），毛利率${value.grossMargin === undefined ? "暂无可靠数据" : `${value.grossMargin.toFixed(2)}%`}，经营现金流${amount(value.operatingCashFlow)}。`;
};
