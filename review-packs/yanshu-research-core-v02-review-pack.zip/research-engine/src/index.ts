import type { CompanyResearchBrief } from "@yanshu/research-schema";
import type { PublicCompanySummary } from "@yanshu/data-providers";
import {
  CninfoAnnouncementProvider,
  DerivedIndustryProvider,
  EastmoneyCompanyProfileProvider,
  FallbackMarketDataProvider,
  PublicFeedProvider,
  SinaFinancialDataProvider,
} from "@yanshu/data-providers";
import { CompanyResearchEngine } from "./company-research-engine.js";

export type ResearchAvailability = "ready" | "partial" | "unknown";

export type ResearchEngineResult = {
  availability: ResearchAvailability;
  brief: CompanyResearchBrief | null;
  missing: string[];
};

export interface ResearchEngine {
  search(query: string): Promise<PublicCompanySummary[]>;
  companyBrief(code: string): Promise<ResearchEngineResult>;
  health?(): Promise<Record<string, unknown>>;
}

export class UnconfiguredResearchEngine implements ResearchEngine {
  async search(_query: string): Promise<PublicCompanySummary[]> {
    return [];
  }

  async companyBrief(code: string): Promise<ResearchEngineResult> {
    if (!/^\d{6}$/.test(code)) throw new Error("股票代码必须是六位数字");
    return {
      availability: "unknown",
      brief: null,
      missing: ["标准化公司数据", "研究证据", "产业映射", "研究综合结果"],
    };
  }

  async health(): Promise<Record<string, unknown>> {
    return { researchEngine: "unconfigured", providers: {} };
  }
}

export { CompanyResearchEngine, CompanyResearchEngine as PublicFeedResearchEngine } from "./company-research-engine.js";

export const createPublicFeedResearchEngine = (baseUrl?: string): CompanyResearchEngine => {
  const profile = new EastmoneyCompanyProfileProvider();
  return new CompanyResearchEngine(new PublicFeedProvider(baseUrl), {
    market: new FallbackMarketDataProvider(),
    profile,
    financial: new SinaFinancialDataProvider(),
    announcements: new CninfoAnnouncementProvider(),
    industry: new DerivedIndustryProvider(profile),
  });
};
