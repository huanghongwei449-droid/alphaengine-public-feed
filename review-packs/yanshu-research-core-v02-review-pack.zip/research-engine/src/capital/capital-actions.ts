import type { CompanyResearchBrief } from "@yanshu/research-schema";

export const capitalType = (title: string): CompanyResearchBrief["earningsAndCapital"]["capitalActions"][number]["type"] | null => {
  const pairs: Array<[RegExp, CompanyResearchBrief["earningsAndCapital"]["capitalActions"][number]["type"]]> = [
    [/回购/, "回购"],
    [/增持/, "增持"],
    [/减持/, "减持"],
    [/定增|非公开发行/, "定增"],
    [/激励/, "股权激励"],
    [/并购|收购|重组/, "并购"],
    [/资产注入/, "资产注入"],
    [/解禁/, "解禁"],
  ];
  return pairs.find(([pattern]) => pattern.test(title))?.[1] ?? null;
};
