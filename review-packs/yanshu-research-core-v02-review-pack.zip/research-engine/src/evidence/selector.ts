import { freshnessRank } from "./freshness.js";
import { isMaterialEvidence } from "./normalize.js";
import type { EvidenceSelectorOptions, NormalizedEvidence } from "./types.js";

const dateMs = (value?: string): number => value ? Date.parse(value) || 0 : 0;
const canonical = (value: string): string => value.toLowerCase().replace(/摘要|全文|正文/g, "").replace(/[：:，,。.!！?？\s]/g, "");

export const dedupeEvidence = (items: NormalizedEvidence[]): NormalizedEvidence[] => {
  const map = new Map<string, NormalizedEvidence>();
  for (const item of items) {
    const key = `${item.category}|${canonical(item.title)}|${item.publishedAt?.slice(0, 10) ?? ""}`;
    const previous = map.get(key);
    if (!previous || item.relevance > previous.relevance || freshnessRank(item.freshness) > freshnessRank(previous.freshness)) map.set(key, item);
  }
  return [...map.values()];
};

export const selectEvidence = (items: NormalizedEvidence[], options: EvidenceSelectorOptions = {}): NormalizedEvidence[] => {
  const maxItems = options.maxItems ?? 5;
  const recentDays = options.recentDays ?? 30;
  const now = options.now ?? new Date();
  const recentCutoff = now.getTime() - recentDays * 24 * 60 * 60 * 1000;
  return dedupeEvidence(items)
    .filter((item) => isMaterialEvidence(item) && (item.currentUsable || item.category === "historical_research"))
    .sort((a, b) => {
      const aRecent = dateMs(a.publishedAt) >= recentCutoff ? 1 : 0;
      const bRecent = dateMs(b.publishedAt) >= recentCutoff ? 1 : 0;
      return (b.currentUsable ? 2 : 0) - (a.currentUsable ? 2 : 0) || bRecent - aRecent || freshnessRank(b.freshness) - freshnessRank(a.freshness) || b.relevance - a.relevance || dateMs(b.publishedAt) - dateMs(a.publishedAt);
    })
    .slice(0, maxItems);
};
