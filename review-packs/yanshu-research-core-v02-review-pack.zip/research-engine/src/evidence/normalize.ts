import { freshnessFromPublishedAt } from "./freshness.js";
import { isMaterialAnnouncement, relevanceForTitle } from "./materiality.js";
import type { EvidenceCategory, EvidenceFreshness, EvidenceReliability, NormalizedEvidence } from "./types.js";

const text = (value: unknown): string => typeof value === "string" ? value.trim() : "";
const date = (value: string | undefined): string | undefined => {
  if (!value) return undefined;
  const source = /^\d{4}-\d{2}-\d{2}$/.test(value) ? `${value}T23:59:59.000Z` : value;
  const parsed = new Date(source);
  return Number.isFinite(parsed.getTime()) ? parsed.toISOString() : undefined;
};
const record = (value: unknown): Record<string, unknown> | null => value !== null && typeof value === "object" && !Array.isArray(value) ? value as Record<string, unknown> : null;
const at = (root: unknown, ...keys: string[]): unknown => {
  let value: unknown = root;
  for (const key of keys) {
    const item = record(value);
    if (!item) return undefined;
    value = item[key];
  }
  return value;
};
const stableId = (parts: string[]): string => parts.join("|").toLowerCase().replace(/\s+/g, " ").slice(0, 220);

export type EvidenceInput = {
  code?: string | undefined;
  category: EvidenceCategory;
  title: string;
  fact: string;
  publishedAt?: string | undefined;
  dataAsOf?: string | undefined;
  sourceType: string;
  sourceUrl?: string | undefined;
  reliability: EvidenceReliability;
  relevance?: number | undefined;
  currentUsable?: boolean | undefined;
  now?: Date | undefined;
};

export const normalizeEvidence = (input: EvidenceInput): NormalizedEvidence => {
  const fetchedAt = (input.now ?? new Date()).toISOString();
  const publishedAt = date(input.publishedAt || input.dataAsOf);
  const dataAsOf = date(input.dataAsOf);
  const freshness: EvidenceFreshness = freshnessFromPublishedAt(publishedAt, input.now ?? new Date());
  const currentUsable = input.currentUsable ?? (freshness !== "stale" && freshness !== "unknown");
  return {
    id: stableId([input.code ?? "", input.category, input.title, publishedAt ?? input.fact]),
    ...(input.code ? { code: input.code } : {}),
    category: input.category,
    title: input.title.trim(),
    fact: input.fact.trim(),
    ...(publishedAt ? { publishedAt } : {}),
    fetchedAt,
    ...(dataAsOf ? { dataAsOf } : {}),
    sourceType: input.sourceType,
    ...(input.sourceUrl ? { sourceUrl: input.sourceUrl } : {}),
    reliability: input.reliability,
    freshness,
    relevance: Math.max(0, Math.min(1, input.relevance ?? relevanceForTitle(input.title))),
    currentUsable,
  };
};

export const normalizeFeedFact = (code: string, fact: unknown, now = new Date()): NormalizedEvidence | null => {
  const item = record(fact);
  if (!item) return null;
  const title = text(item.title) || text(item.name) || "公开研究事实";
  const body = text(item.fact) || text(item.summary) || text(item.content) || text(item.detail);
  if (!body) return null;
  const publishedAt = text(item.publishedAt) || text(item.date) || text(item.updatedAt) || undefined;
  return normalizeEvidence({ code, category: "historical_research", title, fact: body, publishedAt, sourceType: "GitHub Public Feed", sourceUrl: text(item.sourceUrl) || undefined, reliability: "medium", relevance: 0.45, currentUsable: false, now });
};

export const normalizeFeedResearch = (code: string, profile: unknown, now = new Date()): NormalizedEvidence[] => {
  const root = record(profile);
  if (!root) return [];
  const memory = record(root.researchMemory);
  const items: NormalizedEvidence[] = [];
  for (const [title, value] of [["历史研究定位", memory?.position], ["历史核心矛盾", memory?.currentTension], ["历史证伪条件", record(root.serenity)?.whatCouldProveWrong]] as Array<[string, unknown]>) {
    const fact = text(value);
    if (!fact) continue;
    items.push(normalizeEvidence({ code, category: "historical_research", title, fact, publishedAt: text(root.updatedAt) || undefined, sourceType: "GitHub Public Feed 历史研究", reliability: "medium", relevance: 0.4, currentUsable: false, now }));
  }
  return items;
};

export const isMaterialEvidence = (evidence: NormalizedEvidence): boolean => evidence.category !== "announcement" || isMaterialAnnouncement(evidence.title);

export const evidenceFromContext = (code: string, context: unknown, now = new Date()): NormalizedEvidence[] => {
  const root = record(context);
  if (!root) return [];
  const price = record(root.price);
  const quote = record(root.quote);
  const change20 = typeof price?.change20 === "number" ? price.change20 : undefined;
  const change60 = typeof price?.change60 === "number" ? price.change60 : undefined;
  const asOf = text(quote?.asOfDate) || text(root.generatedAt) || undefined;
  if (change20 === undefined && change60 === undefined) return [];
  return [normalizeEvidence({ code, category: "historical_research", title: "历史行情快照", fact: `公开 Feed 记录近20日${change20?.toFixed(2) ?? "暂无"}%、近60日${change60?.toFixed(2) ?? "暂无"}%；仅作为历史背景。`, publishedAt: asOf, sourceType: "GitHub Public Feed 历史行情", reliability: "medium", relevance: 0.25, currentUsable: false, now })];
};
