export type EvidenceCategory = "company" | "industry" | "market" | "financial" | "announcement" | "capital_action" | "broker" | "news" | "historical_research";
export type EvidenceReliability = "official" | "high" | "medium" | "low";
export type EvidenceFreshness = "fresh" | "aging" | "stale" | "unknown";

export type NormalizedEvidence = {
  id: string;
  code?: string | undefined;
  category: EvidenceCategory;
  title: string;
  fact: string;
  publishedAt?: string | undefined;
  fetchedAt: string;
  dataAsOf?: string | undefined;
  sourceType: string;
  sourceUrl?: string | undefined;
  reliability: EvidenceReliability;
  freshness: EvidenceFreshness;
  relevance: number;
  currentUsable: boolean;
};

export type EvidenceSelectorOptions = {
  now?: Date;
  maxItems?: number;
  recentDays?: number;
};
