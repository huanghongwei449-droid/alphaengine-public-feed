const procedural = /(召开.*股东大会|股东(大会|会).*(通知|补充通知|提示)|律师.*法律意见|营业执照变更|普通授信|会议提示|会议通知|提示性公告|聘请.*审计|审计机构|董事会.*决议|监事会.*决议|非经营性资金占用.*汇总表)/;
const material = /(业绩|预告|快报|定期报告|回购|增持|减持|解禁|重大合同|中标|并购|重组|问询|诉讼|仲裁|分红|资产注入|对外投资|订单|产能|产品|涨价|停产|复产|重大风险|控制权)/;

export const isMaterialAnnouncement = (title: string): boolean => {
  if (!title.trim()) return false;
  if (material.test(title)) return true;
  return !procedural.test(title);
};

export const relevanceForTitle = (title: string): number => {
  if (material.test(title)) return 0.95;
  if (procedural.test(title)) return 0.1;
  return 0.55;
};
