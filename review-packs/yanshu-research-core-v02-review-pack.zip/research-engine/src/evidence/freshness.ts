import type { EvidenceFreshness } from "./types.js";

const dayStart = (value: Date): Date => new Date(`${value.toISOString().slice(0, 10)}T00:00:00.000Z`);
const isWeekday = (value: Date): boolean => value.getUTCDay() !== 0 && value.getUTCDay() !== 6;

export const tradingDayAge = (asOf: string | undefined, now = new Date()): number | null => {
  if (!asOf) return null;
  const parsed = new Date(asOf);
  if (!Number.isFinite(parsed.getTime())) return null;
  const start = dayStart(parsed);
  const end = dayStart(now);
  if (start > end) return 0;
  let cursor = new Date(start);
  let age = 0;
  while (cursor < end) {
    cursor.setUTCDate(cursor.getUTCDate() + 1);
    if (isWeekday(cursor)) age += 1;
  }
  return age;
};

export const freshnessFromPublishedAt = (publishedAt: string | undefined, now = new Date()): EvidenceFreshness => {
  if (!publishedAt) return "unknown";
  const age = tradingDayAge(publishedAt, now);
  if (age === null) return "unknown";
  if (age <= 1) return "fresh";
  if (age <= 3) return "aging";
  return "stale";
};

export const freshnessRank = (value: EvidenceFreshness): number => ({ fresh: 4, aging: 3, stale: 1, unknown: 0 }[value]);
