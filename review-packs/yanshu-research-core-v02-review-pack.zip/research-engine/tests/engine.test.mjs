import test from "node:test";
import assert from "node:assert/strict";
import { UnconfiguredResearchEngine } from "../dist/index.js";

test("未配置数据时返回 unknown，而不是伪造研究结论", async () => {
  const result = await new UnconfiguredResearchEngine().companyBrief("300017");
  assert.equal(result.availability, "unknown");
  assert.equal(result.brief, null);
  assert.ok(result.missing.length > 0);
});
